import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useSelector, useDispatch } from 'react-redux';
import { addWidget, removeWidget } from '../redux/store';

function Dashboard() {
  const [search, setSearch] = useState('');
  const [newWidget, setNewWidget] = useState('');
  const widgets = useSelector(state => state.widgets);
  const dispatch = useDispatch();

  const handleAdd = () => {
    if (newWidget.trim() !== '') {
      dispatch(addWidget(newWidget));
      setNewWidget('');
    }
  };

  const handleRemove = (id) => {
    dispatch(removeWidget(id));
  };

  const filteredWidgets = widgets.filter(widget =>
    widget.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div>
      <input
        type="text"
        placeholder="Search widgets"
        className="border p-2 rounded mb-4 w-full"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />
      <div className="flex gap-2 mb-4">
        <input
          type="text"
          placeholder="New Widget Name"
          className="border p-2 rounded w-full"
          value={newWidget}
          onChange={(e) => setNewWidget(e.target.value)}
        />
        <button
          onClick={handleAdd}
          className="bg-blue-500 text-white px-4 rounded"
        >
          Add
        </button>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {filteredWidgets.map((widget) => (
          <motion.div
            key={widget.id}
            className="p-4 border rounded shadow relative"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
          >
            <button
              onClick={() => handleRemove(widget.id)}
              className="absolute top-2 right-2 text-red-500"
            >
              ✖
            </button>
            {widget.title}
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default Dashboard;
