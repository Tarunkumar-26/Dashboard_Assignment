import { configureStore, createSlice } from '@reduxjs/toolkit';

const widgetSlice = createSlice({
  name: 'widgets',
  initialState: [],
  reducers: {
    addWidget: (state, action) => {
      state.push({ id: Date.now(), title: action.payload });
    },
    removeWidget: (state, action) => {
      return state.filter(widget => widget.id !== action.payload);
    }
  }
});

export const { addWidget, removeWidget } = widgetSlice.actions;

export default configureStore({
  reducer: {
    widgets: widgetSlice.reducer
  }
});
